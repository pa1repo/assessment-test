﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AspDotNetCoreWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataController : ControllerBase
    {
        [HttpPost]
        public IActionResult GetData()
        {
            var students = new List<Student>
            {
                new Student
                {
                    Name = "Alice",
                    Age = 20,
                    Hobbies = new List<string> { "reading", "swimming", "coding" }
                },
                new Student
                {
                    Name = "Bob",
                    Age = 22,
                    Hobbies = new List<string> { "painting", "dancing", "singing" }
                }
            };

            var data = new { students };
            return Ok(data);
        }
    }
    public class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public List<string> Hobbies { get; set; }
    }
}
