import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { process, State } from '@progress/kendo-data-query';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit {
  students: any[];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.http.post<any>('https://localhost:{3000}//data', {})
      .subscribe(response => {
        this.students = response.students;
      });
  }
}
